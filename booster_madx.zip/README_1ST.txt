Readme 1ST
========

The booster lattice files are in MADX format.

Just download the
     	      booster_madx.zip
file which contains all the required files for MADX.




